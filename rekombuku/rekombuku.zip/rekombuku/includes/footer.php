</main>
    <footer>
        <p>&copy; 2024 Book Recommendation. All rights reserved.</p>
    </footer>
</body>
</html>
